"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const electron_1 = require("electron");
const node_child_process_1 = require("node:child_process");
const node_fs_1 = __importDefault(require("node:fs"));
const node_http_1 = __importDefault(require("node:http"));
const node_os_1 = __importDefault(require("node:os"));
const node_path_1 = __importDefault(require("node:path"));
let backendProcess = null;
let mainWindow = null;
let lastSpawnError = null;
// Prevent unhandled main-process errors from triggering macOS native crash dialogs
process.on('uncaughtException', (err) => {
    console.error('[HOME OS Electron] Uncaught exception:', err);
});
process.on('unhandledRejection', (reason) => {
    console.error('[HOME OS Electron] Unhandled rejection:', reason);
});
function inspectBackendHealth(port) {
    return new Promise((resolve) => {
        const req = node_http_1.default.get({
            hostname: '127.0.0.1',
            port: Number(port),
            path: '/api/v1/health',
            timeout: 1200,
        }, (res) => {
            let raw = '';
            res.setEncoding('utf8');
            res.on('data', (chunk) => {
                raw += chunk;
            });
            res.on('end', () => {
                if (res.statusCode !== 200) {
                    resolve({ ok: false });
                    return;
                }
                try {
                    const parsed = JSON.parse(raw);
                    resolve({
                        ok: true,
                        bindHost: parsed.bind_host,
                        apiRevision: parsed.api_revision,
                    });
                }
                catch {
                    resolve({ ok: true });
                }
            });
        });
        req.on('error', () => resolve({ ok: false }));
        req.on('timeout', () => {
            req.destroy();
            resolve({ ok: false });
        });
    });
}
function stopStalePortListener(port) {
    if (process.platform === 'win32')
        return;
    for (const lsofBin of ['/usr/sbin/lsof', '/usr/bin/lsof', 'lsof']) {
        try {
            const out = (0, node_child_process_1.execFileSync)(lsofBin, ['-ti', `tcp:${port}`], { encoding: 'utf8', timeout: 1500 }).trim();
            if (out) {
                for (const pidStr of out.split(/\s+/)) {
                    const pid = Number(pidStr);
                    if (pid > 1 && pid !== process.pid) {
                        try {
                            process.kill(pid, 'SIGTERM');
                        }
                        catch {
                            // ignore
                        }
                    }
                }
                return;
            }
        }
        catch {
            continue;
        }
    }
}
function resolveHomeOsBinary() {
    const home = node_os_1.default.homedir();
    const candidates = [
        process.env.HOMEOS_PYTHON_BIN,
        node_path_1.default.join(home, '.local', 'bin', 'homeos'),
        node_path_1.default.join(home, '.local', 'share', 'home-os', 'venv', 'bin', 'homeos'),
        '/opt/homebrew/bin/homeos',
        '/usr/local/bin/homeos',
        '/usr/bin/homeos',
    ].filter((c) => Boolean(c));
    for (const bin of candidates) {
        try {
            if (node_fs_1.default.existsSync(bin)) {
                return bin;
            }
        }
        catch {
            // ignore fs errors
        }
    }
    return null;
}
function resolveBundledUiDir() {
    const home = node_os_1.default.homedir();
    const resPath = process.resourcesPath || '';
    const candidates = [
        node_path_1.default.join(resPath, 'ui-dist'),
        node_path_1.default.resolve(__dirname, '..', 'dist'),
        node_path_1.default.join(home, '.local', 'share', 'home-os', 'ui-dist'),
    ];
    for (const dir of candidates) {
        try {
            if (node_fs_1.default.existsSync(node_path_1.default.join(dir, 'index.html'))) {
                return dir;
            }
        }
        catch {
            // ignore
        }
    }
    return undefined;
}
async function ensureLocalBackendRunning(port) {
    const initial = await inspectBackendHealth(port);
    if (initial.ok) {
        if (process.env.HOMEOS_EXTERNAL_BACKEND === '1') {
            return true;
        }
        // If an older pre-2.0 instance or a loopback-only instance is holding port 8420, replace it
        if (initial.bindHost === '0.0.0.0' && initial.apiRevision === '2.0.0') {
            return true;
        }
        stopStalePortListener(port);
        await new Promise((r) => setTimeout(r, 500));
    }
    else if (process.env.HOMEOS_EXTERNAL_BACKEND === '1') {
        return false;
    }
    const binPath = resolveHomeOsBinary();
    if (!binPath) {
        lastSpawnError =
            'Could not locate ~/.local/bin/homeos. Run `bash scripts/install-macos.sh` in your HOME-OS folder first, or start `homeos serve` in Terminal.';
        return false;
    }
    const home = node_os_1.default.homedir();
    const dataDir = node_path_1.default.join(home, '.local', 'share', 'home-os', 'data');
    try {
        node_fs_1.default.mkdirSync(dataDir, { recursive: true });
    }
    catch {
        // ignore
    }
    const staticDir = resolveBundledUiDir();
    const augmentedPath = [
        node_path_1.default.join(home, '.local', 'bin'),
        node_path_1.default.join(home, '.local', 'share', 'home-os', 'platform-tools'),
        '/opt/homebrew/bin',
        '/usr/local/bin',
        process.env.PATH || '/usr/bin:/bin:/usr/sbin:/sbin',
    ].join(':');
    try {
        const logFd = node_fs_1.default.openSync(node_path_1.default.join(dataDir, 'hub.log'), 'a');
        backendProcess = (0, node_child_process_1.spawn)(binPath, ['serve', '--host', '0.0.0.0', '--port', port], {
            cwd: dataDir,
            stdio: ['ignore', logFd, logFd],
            env: {
                ...process.env,
                PATH: augmentedPath,
                HOMEOS_BIND_HOST: '0.0.0.0',
                HOMEOS_AUTO_ENROLL_HOST: '1',
                HOMEOS_DATA_DIR: dataDir,
                ...(staticDir ? { HOMEOS_STATIC_DIR: staticDir } : {}),
            },
        });
        node_fs_1.default.closeSync(logFd);
        backendProcess.on('error', (err) => {
            lastSpawnError = err.message;
            backendProcess = null;
        });
    }
    catch (err) {
        lastSpawnError = err instanceof Error ? err.message : String(err);
        return false;
    }
    for (let attempt = 0; attempt < 45; attempt++) {
        const h = await inspectBackendHealth(port);
        if (h.ok) {
            return true;
        }
        await new Promise((r) => setTimeout(r, 300));
    }
    return false;
}
function buildDiagnosticHtml(targetUrl, detail) {
    const escaped = detail.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    const html = `<!doctype html>
<html>
<head>
<meta charset="utf-8"/>
<title>HOME OS — Starting Core Engine</title>
<style>
  body { margin:0; font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif; background:#090B10; color:#F3F4F6; display:flex; align-items:center; justify-content:center; height:100vh; }
  .box { max-width:540px; background:#111622; border:1px solid #1F2937; border-radius:14px; padding:28px; box-shadow:0 20px 50px rgba(0,0,0,.5); }
  h2 { margin:0 0 10px; font-size:18px; }
  p { color:#9CA3AF; font-size:13.5px; line-height:1.55; }
  code { display:block; background:#090B10; border:1px solid #1F2937; padding:10px 12px; border-radius:8px; font-family:ui-monospace,SFMono-Regular,Menlo,monospace; font-size:12px; color:#38BDF8; margin:12px 0; white-space:pre-wrap; }
  button { background:#0284C7; color:#fff; border:none; border-radius:8px; padding:10px 16px; font-weight:600; cursor:pointer; font-size:13px; }
  button:hover { background:#0369A1; }
</style>
</head>
<body>
  <div class="box">
    <h2>HOME OS Local Core Not Reachable Yet</h2>
    <p>${escaped}</p>
    <code>bash scripts/install-macos.sh
~/.local/bin/homeos serve --host 127.0.0.1 --port 8420</code>
    <button onclick="window.location.href='${targetUrl}'">Connect to ${targetUrl}</button>
  </div>
</body>
</html>`;
    return `data:text/html;charset=utf-8,${encodeURIComponent(html)}`;
}
async function createCommandWindow() {
    const port = process.env.HOMEOS_BIND_PORT || '8420';
    const targetUrl = process.env.HOMEOS_DESKTOP_URL || `http://127.0.0.1:${port}`;
    mainWindow = new electron_1.BrowserWindow({
        width: 1440,
        height: 920,
        minWidth: 1024,
        minHeight: 700,
        title: 'HOME OS',
        backgroundColor: '#090B10',
        webPreferences: {
            preload: node_path_1.default.join(__dirname, 'preload.js'),
            contextIsolation: true,
            nodeIntegration: false,
            sandbox: true,
        },
    });
    mainWindow.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
    const bootHtml = `data:text/html;charset=utf-8,${encodeURIComponent('<!doctype html><html><body style="margin:0;background:#090B10;color:#9CA3AF;font-family:-apple-system,sans-serif;display:flex;align-items:center;justify-content:center;height:100vh;font-size:14px;">Starting HOME OS Local Core Engine...</body></html>')}`;
    await mainWindow.loadURL(bootHtml).catch(() => { });
    const ready = await ensureLocalBackendRunning(port);
    if (ready && mainWindow && !mainWindow.isDestroyed()) {
        try {
            await mainWindow.loadURL(targetUrl);
            return;
        }
        catch (err) {
            lastSpawnError = err instanceof Error ? err.message : String(err);
        }
    }
    if (mainWindow && !mainWindow.isDestroyed()) {
        const msg = lastSpawnError ||
            `Timed out waiting for local Core Engine on ${targetUrl}. Start 'homeos serve' in Terminal and click Connect.`;
        await mainWindow.loadURL(buildDiagnosticHtml(targetUrl, msg)).catch(() => { });
    }
}
electron_1.ipcMain.handle('homeos:platform-info', () => ({
    shell: 'electron',
    platform: process.platform,
    arch: process.arch,
    version: '2.0.0',
}));
electron_1.app.whenReady().then(async () => {
    await createCommandWindow();
    electron_1.app.on('activate', () => {
        if (electron_1.BrowserWindow.getAllWindows().length === 0) {
            void createCommandWindow();
        }
    });
});
electron_1.app.on('before-quit', () => {
    if (backendProcess) {
        try {
            backendProcess.kill('SIGTERM');
        }
        catch {
            // ignore
        }
        backendProcess = null;
    }
});
electron_1.app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') {
        electron_1.app.quit();
    }
});
